import { MessageCircle, Check } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { waLink, services } from "../../lib/site";

const facts = [
  { label: "Raison sociale", value: "TECHNO FAB SARL-U" },
  { label: "Création", value: "2021" },
  { label: "Directeur Général", value: "M. MISSIAMENOU YAWOVI" },
  { label: "Siège", value: "Lomé, Bè Kpota Colas — Togo" },
  { label: "NIF", value: "1001751745" },
  { label: "Zone d'intervention", value: "Lomé et environs" },
];

const stats = [
  { value: "2021", label: "Depuis la création" },
  { value: "6", label: "Domaines d'activité" },
  { value: "2", label: "Lignes directes" },
  { value: "1", label: "Direction stable" },
];

export default function About() {
  return (
    <section id="apropos" className="scroll-mt-24 bg-white px-5 md:px-10 py-14 md:py-24">
      <div className="mx-auto max-w-6xl grid gap-10 lg:grid-cols-[1.05fr_0.95fr] lg:items-start">
        <div>
          <SectionHeading
            eyebrow="À PROPOS"
            title="Une PME togolaise dirigée depuis sa création par le même fondateur"
          />
          <div className="mt-5 space-y-4 text-[15px] leading-[1.75] text-[#4C5F70]">
            <p>
              TECHNO FAB SARL-U est née en 2021 à Lomé, dans le quartier de Bè
              Kpota Colas, sous l'impulsion de Monsieur MISSIAMENOU YAWOVI. Le
              principe de départ est resté le même : comprendre la consommation
              et les contraintes réelles du client avant de proposer une
              installation.
            </p>
            <p>
              Depuis, l'entreprise accompagne des particuliers, des commerçants,
              des bureaux, des PME et des ONG de la capitale et de ses environs,
              sur six domaines d'activité complémentaires.
            </p>
            <p>
              Notre promesse tient en peu de mots : des installations fiables,
              étudiées et garanties. Nous restons joignables après la mise en
              service, parce qu'un chantier ne se termine pas à la remise du
              matériel.
            </p>
          </div>

          <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
            {services.map((service) => (
              <li key={service.title} className="flex items-center gap-2 text-[13.5px] text-[#3A4B5C]">
                <span className="w-5 h-5 rounded-full bg-[#EAF7F5] text-[#2A9D8F] flex items-center justify-center shrink-0">
                  <Check size={12} strokeWidth={3} />
                </span>
                {service.title}
              </li>
            ))}
          </ul>

          <div className="mt-7 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="rounded-xl border border-[#E9EDF2] bg-[#F8F9FA] px-3 py-3.5"
              >
                <p className="[font-family:var(--font-montserrat)] text-xl font-extrabold text-[#0076C0]">
                  {stat.value}
                </p>
                <p className="mt-1 text-[11px] leading-tight text-[#6B7C8F]">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-[#E9EDF2] bg-white p-6 md:p-7 shadow-[0_24px_50px_-32px_rgba(0,118,192,0.45)]">
          <p className="text-[11px] font-semibold tracking-[0.2em] text-[#00B4D8]">
            IDENTIFICATION DE L'ENTREPRISE
          </p>
          <dl className="mt-4 divide-y divide-[#F1F4F8]">
            {facts.map((fact) => (
              <div key={fact.label} className="flex flex-col gap-0.5 py-3">
                <dt className="text-[11px] uppercase tracking-wider text-[#93A2B1]">
                  {fact.label}
                </dt>
                <dd className="text-[14px] font-medium text-[#0E2C42]">
                  {fact.value}
                </dd>
              </div>
            ))}
          </dl>
          <a
            href={waLink("Bonjour TECHNO FAB, je souhaite des informations sur votre entreprise.")}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 inline-flex w-full items-center justify-center gap-2 min-h-[50px] rounded-[10px] bg-gradient-to-r from-[#0076C0] to-[#00B4D8] text-white text-sm font-semibold whitespace-nowrap shadow-[0_10px_24px_-12px_rgba(0,118,192,0.9)] hover:shadow-[0_14px_28px_-12px_rgba(0,118,192,1)] transition-all duration-200 cursor-pointer"
          >
            <MessageCircle size={17} strokeWidth={2.2} />
            Nous contacter sur WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}