type SectionHeadingProps = {
  eyebrow: string;
  title: string;
  description?: string;
  light?: boolean;
  centered?: boolean;
};

export default function SectionHeading({
  eyebrow,
  title,
  description,
  light = false,
  centered = false,
}: SectionHeadingProps) {
  return (
    <div className={`max-w-2xl ${centered ? "mx-auto text-center" : ""}`}>
      <p
        className={`text-[11px] font-semibold tracking-[0.2em] ${
          light ? "text-[#7FE3F5]" : "text-[#00B4D8]"
        }`}
      >
        {eyebrow}
      </p>
      <h2
        className={`mt-3 [font-family:var(--font-montserrat)] font-extrabold tracking-tight text-[26px] leading-[1.22] md:text-[36px] ${
          light ? "text-white" : "text-[#0076C0]"
        }`}
      >
        {title}
      </h2>
      {description && (
        <p
          className={`mt-4 text-[15px] leading-[1.7] ${
            light ? "text-white/75" : "text-[#5A6B7C]"
          }`}
        >
          {description}
        </p>
      )}
    </div>
  );
}