import { MessageCircle, Images } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { WA_REALISATIONS } from "../../lib/site";

const photos = [
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/1834f8aa-4b01-459a-84e0-1b8c85027872_compressed_IMG-20260514-WA0013.webp",
    title: "Installation solaire",
    caption: "Panneaux posés et câblés sur toiture",
  },
  {
    src: "https://readdy.ai/api/search-image?query=Photograph%20of%20a%20neatly%20wired%20electrical%20distribution%20panel%20with%20circuit%20breakers%20and%20colored%20cables%20perfectly%20labeled%2C%20mounted%20on%20a%20clean%20light%20grey%20wall%2C%20professional%20technician%20workmanship%2C%20even%20soft%20lighting%2C%20simple%20minimal%20background%2C%20technical%20documentary%20photography%2C%20sharp%20details&width=800&height=600&seq=real-tableau-02&orientation=landscape",
    title: "Tableau électrique",
    caption: "Câblage repéré et mise aux normes",
  },
  {
    src: "https://readdy.ai/api/search-image?query=Photograph%20of%20a%20white%20security%20surveillance%20camera%20mounted%20on%20the%20exterior%20wall%20of%20a%20shop%20in%20West%20Africa%2C%20discreet%20cable%20routing%2C%20soft%20daylight%2C%20simple%20clean%20wall%20background%2C%20professional%20technical%20documentary%20photography%2C%20sharp%20details%2C%20neutral%20colors&width=800&height=600&seq=real-camera-03&orientation=landscape",
    title: "Caméras de surveillance",
    caption: "Vision 24h/24 et accès depuis le mobile",
  },
  {
    src: "https://readdy.ai/api/search-image?query=Photograph%20of%20a%20traffic%20light%20system%20installed%20at%20a%20road%20intersection%20in%20a%20West%20African%20city%2C%20clean%20metal%20pole%20with%20three%20signal%20heads%2C%20organized%20wiring%2C%20soft%20daylight%2C%20simple%20uncluttered%20street%20background%2C%20professional%20technical%20documentary%20photography%2C%20sharp%20details&width=800&height=600&seq=real-feux-04&orientation=landscape",
    title: "Feux tricolores",
    caption: "Mise en service sur carrefour",
  },
];

export default function Realisations() {
  return (
    <section id="realisations" className="scroll-mt-24 bg-[#F8F9FA] px-5 md:px-10 py-14 md:py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="NOS RÉALISATIONS"
          title="Nos réalisations sur le terrain"
          description="Découvrez quelques-unes de nos interventions, notamment en énergie solaire."
        />

        <div className="mt-10 grid gap-4 sm:gap-5 md:grid-cols-2">
          {photos.map((photo) => (
            <figure
              key={photo.title}
              className="group relative overflow-hidden rounded-[12px] border border-[#E6EDF3] bg-white shadow-[0_2px_12px_rgba(15,42,66,0.05)] transition-all duration-300 hover:border-[#00B4D8] hover:shadow-[0_20px_40px_-24px_rgba(0,118,192,0.45)]"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={photo.src}
                  alt={`${photo.title} — chantier TECHNO FAB à Lomé`}
                  loading="lazy"
                  className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-[1.06]"
                />
              </div>
              <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#062E4A]/88 via-[#062E4A]/55 to-transparent px-5 pb-4 pt-12">
                <p className="[font-family:var(--font-montserrat)] text-[15px] md:text-[16px] font-bold text-white">
                  {photo.title}
                </p>
                <p className="mt-1 text-[12.5px] text-white/80">{photo.caption}</p>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 rounded-2xl border border-[#DCEAF3] bg-white px-5 py-6 md:px-8">
          <p className="inline-flex items-center gap-2.5 text-sm md:text-[15px] text-[#4C5F70] text-center sm:text-left">
            <span className="hidden sm:flex w-9 h-9 rounded-lg bg-[#EAF7F5] text-[#2A9D8F] items-center justify-center">
              <Images size={17} />
            </span>
            Envie de voir d'autres chantiers ? Demandez-nous les photos.
          </p>
          <a
            href={WA_REALISATIONS}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 min-h-[50px] px-6 rounded-[10px] bg-gradient-to-r from-[#25D366] to-[#1FB35A] text-white text-sm font-semibold whitespace-nowrap shadow-[0_8px_20px_-10px_rgba(37,211,102,0.8)] hover:shadow-[0_10px_26px_-10px_rgba(37,211,102,0.9)] transition-all duration-200 cursor-pointer"
          >
            <MessageCircle size={17} strokeWidth={2.3} />
            Voir plus de photos sur WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}