import Link from "next/link";
import {
  PHONE_PRIMARY_DISPLAY,
  PHONE_PRIMARY_HREF,
  PHONE_SECONDARY_DISPLAY,
  PHONE_SECONDARY_HREF,
  services,
  LOGO_URL,
} from "../../lib/site";
import LegalNotice from "./LegalNotice";

export default function Footer() {
  return (
    <footer
      className="text-white px-5 md:px-10 pt-12 pb-24 md:pb-10"
      style={{ background: "linear-gradient(150deg,#062E4A 0%,#0076C0 100%)" }}
    >
      <div className="mx-auto max-w-6xl grid gap-9 md:grid-cols-[1.2fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <span className="w-12 h-12 rounded-xl bg-white flex items-center justify-center p-1.5 shadow-[0_8px_20px_-10px_rgba(0,0,0,0.5)]">
              <img
                src={LOGO_URL}
                alt="Logo TECHNO FAB"
                className="w-full h-full object-contain"
              />
            </span>
            <span>
              <span className="block [font-family:var(--font-montserrat)] font-extrabold text-[16px]">
                TECHNO FAB
              </span>
              <span className="block text-[10px] tracking-[0.16em] text-white/60">
                SARL-U • LOMÉ
              </span>
            </span>
          </div>
          <p className="mt-4 max-w-sm text-[13.5px] leading-[1.75] text-white/70">
            Énergie solaire, efficacité énergétique, électricité, courant faible,
            caméras de surveillance et feux tricolores. Expérience et dynamisme
            depuis 2021.
          </p>
          <p className="mt-4 text-[12px] text-white/55">NIF : 1001751745</p>
        </div>

        <div>
          <p className="text-[11px] font-semibold tracking-[0.2em] text-[#9BE9F7]">
            SERVICES
          </p>
          <ul className="mt-4 space-y-2.5">
            {services.map((service) => (
              <li key={service.title}>
                <Link
                  href="#services"
                  className="text-[13.5px] text-white/70 hover:text-white transition-colors duration-200 cursor-pointer"
                >
                  {service.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="text-[11px] font-semibold tracking-[0.2em] text-[#9BE9F7]">
            COORDONNÉES
          </p>
          <ul className="mt-4 space-y-2.5 text-[13.5px] text-white/70">
            <li>Lomé, Bè Kpota Colas — Togo</li>
            <li>
              <a href={PHONE_PRIMARY_HREF} className="hover:text-white transition-colors duration-200 cursor-pointer">
                {PHONE_PRIMARY_DISPLAY}
              </a>
            </li>
            <li>
              <a href={PHONE_SECONDARY_HREF} className="hover:text-white transition-colors duration-200 cursor-pointer">
                {PHONE_SECONDARY_DISPLAY}
              </a>
            </li>
            <li>Lundi – Samedi, 8h – 18h</li>
            <li>Direction : M. MISSIAMENOU YAWOVI</li>
          </ul>
        </div>
      </div>

      <div className="mx-auto mt-10 max-w-6xl border-t border-white/15 pt-5 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4">
          <p className="text-[12px] text-white/55">
            © 2026 TECHNO FAB SARL-U. Tous droits réservés.
          </p>
          <span className="hidden sm:block h-3 w-px bg-white/20" aria-hidden />
          <LegalNotice />
        </div>
        <p className="text-[12px] text-white/55">Expérience et dynamisme</p>
      </div>
    </footer>
  );
}