import { Phone, ArrowDown, MessageCircle, Check, ShieldCheck } from "lucide-react";
import {
  WA_DEVIS,
  PHONE_PRIMARY_HREF,
  PHONE_PRIMARY_DISPLAY,
  LOGO_URL,
} from "../../lib/site";

const HERO_CTA_LABEL = "Demander un devis sur WhatsApp";

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-[#F8F9FA]">
      <div
        aria-hidden
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 88% 8%, rgba(0,180,216,0.18), transparent 46%), radial-gradient(circle at 6% 96%, rgba(42,157,143,0.12), transparent 48%), radial-gradient(circle at 62% 42%, rgba(0,118,192,0.08), transparent 55%)",
        }}
      />
      <div
        aria-hidden
        className="absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(0,118,192,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(0,118,192,0.06) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage: "radial-gradient(circle at 50% 30%, black, transparent 78%)",
          WebkitMaskImage: "radial-gradient(circle at 50% 30%, black, transparent 78%)",
        }}
      />

      <div className="relative px-5 md:px-10 pt-10 pb-14 md:pt-20 md:pb-24">
        <div className="mx-auto max-w-6xl grid gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
          <div className="w-full">
            <span className="inline-flex items-center gap-2 rounded-full border border-[#D7EDF5] bg-white/80 px-3.5 py-2 text-[11px] md:text-xs font-medium text-[#0076C0] shadow-[0_2px_10px_rgba(0,118,192,0.06)]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#2A9D8F]" />
              Depuis 2021 • Bè Kpota Colas, Lomé
            </span>

            <h1 className="mt-5 [font-family:var(--font-montserrat)] font-extrabold tracking-tight text-[#0076C0] text-[30px] leading-[1.16] sm:text-[40px] md:text-[52px] md:leading-[1.08]">
              Énergie, électricité et{" "}
              <span className="text-[#F4A261]">sécurité</span>,{" "}
              <span className="text-[#00B4D8]">installées proprement</span> à Lomé.
            </h1>

            <p className="mt-5 max-w-xl text-[15px] md:text-[17px] leading-[1.7] text-[#4C5F70]">
              Étude, dimensionnement et installation de systèmes solaires, de
              réseaux électriques, de caméras de surveillance et de feux
              tricolores. Une équipe togolaise qui répond, chiffre et revient
              après la pose.
            </p>

            <div className="mt-7 flex flex-col sm:flex-row gap-3">
              <a
                href={WA_DEVIS}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 min-h-[54px] px-6 rounded-[10px] bg-gradient-to-r from-[#25D366] to-[#1FB35A] text-white text-[15px] font-semibold whitespace-nowrap shadow-[0_10px_24px_-10px_rgba(37,211,102,0.85)] hover:shadow-[0_12px_28px_-10px_rgba(37,211,102,0.95)] transition-all duration-200 cursor-pointer"
              >
                <MessageCircle size={19} strokeWidth={2.3} />
                <span>{HERO_CTA_LABEL}</span>
              </a>
              <a
                href="#services"
                className="inline-flex items-center justify-center gap-2 min-h-[54px] px-6 rounded-[10px] bg-white border border-[#00B4D8] text-[#0076C0] text-[15px] font-semibold whitespace-nowrap hover:bg-[#F0FAFD] transition-colors duration-200 cursor-pointer"
              >
                Voir nos services
                <ArrowDown size={17} />
              </a>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-x-9 gap-y-4">
              {[
                { value: "2021", label: "Année de création" },
                { value: "6", label: "Spécialités techniques" },
                { value: "100 %", label: "Installations garanties" },
              ].map((stat) => (
                <div key={stat.label} className="min-w-[104px]">
                  <p className="[font-family:var(--font-montserrat)] text-2xl font-extrabold text-[#0076C0]">
                    {stat.value}
                  </p>
                  <p className="mt-0.5 text-[11px] md:text-xs text-[#6B7C8F]">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>

            <a
              href={PHONE_PRIMARY_HREF}
              className="mt-6 inline-flex items-center gap-2 py-2 text-sm font-medium text-[#4C5F70] hover:text-[#0076C0] transition-colors duration-200 cursor-pointer"
            >
              <Phone size={15} className="text-[#2A9D8F]" />
              Appeler directement : {PHONE_PRIMARY_DISPLAY}
            </a>
          </div>

          <div className="relative hidden md:flex items-center justify-center">
            <div
              aria-hidden
              className="absolute w-[330px] h-[330px] rounded-full blur-[70px] opacity-40"
              style={{
                background:
                  "linear-gradient(135deg,#00B4D8,#2A9D8F)",
              }}
            />
            <img
              src={LOGO_URL}
              alt="Logo TECHNO FAB SARL-U"
              className="relative w-[300px] lg:w-[340px] h-auto object-contain"
              style={{ mixBlendMode: "multiply" }}
            />
            <div className="absolute -left-2 top-6 flex items-center gap-2 rounded-xl border border-[#E4F1F6] bg-white/90 backdrop-blur px-3 py-2 shadow-[0_14px_30px_-18px_rgba(0,118,192,0.5)]">
              <ShieldCheck size={16} className="text-[#2A9D8F]" />
              <span className="text-[12px] font-medium text-[#1E3A4F]">
                Installations garanties
              </span>
            </div>
            <div className="absolute -right-1 bottom-8 flex items-center gap-2 rounded-xl border border-[#E4F1F6] bg-white/90 backdrop-blur px-3 py-2 shadow-[0_14px_30px_-18px_rgba(0,118,192,0.5)]">
              <Check size={16} className="text-[#00B4D8]" strokeWidth={3} />
              <span className="text-[12px] font-medium text-[#1E3A4F]">
                Devis sous 24h ouvrées
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}