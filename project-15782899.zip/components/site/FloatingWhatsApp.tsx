import { MessageCircle } from "lucide-react";
import { WA_DEVIS } from "../../lib/site";

export default function FloatingWhatsApp() {
  return (
    <a
      href={WA_DEVIS}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Discuter avec TECHNO FAB sur WhatsApp"
      className="fixed bottom-5 right-5 z-50 w-14 h-14 rounded-full bg-gradient-to-br from-[#25D366] to-[#1AA952] text-white flex items-center justify-center shadow-[0_12px_30px_-6px_rgba(37,211,102,0.6)] hover:scale-105 transition-transform duration-200 cursor-pointer"
    >
      <span className="absolute inset-0 rounded-full bg-[#25D366] opacity-50 animate-ping" />
      <MessageCircle size={26} strokeWidth={2.2} className="relative" />
    </a>
  );
}