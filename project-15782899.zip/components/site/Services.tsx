import { Sun, Lightbulb, Zap, Network, Camera, TrafficCone, MessageCircle, ArrowRight } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { services, waLink, WA_DEVIS } from "../../lib/site";

const icons = [Sun, Lightbulb, Zap, Network, Camera, TrafficCone];

const tones = [
  { color: "#F4A261", bg: "#FEF4EC" },
  { color: "#2A9D8F", bg: "#EAF7F5" },
  { color: "#0076C0", bg: "#EAF4FB" },
  { color: "#00B4D8", bg: "#E8F8FC" },
  { color: "#0076C0", bg: "#EAF4FB" },
  { color: "#F4A261", bg: "#FEF4EC" },
];

export default function Services() {
  return (
    <section id="services" className="scroll-mt-24 bg-white px-5 md:px-10 py-14 md:py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="NOS SERVICES"
          title="Six spécialités techniques, un seul interlocuteur à Lomé"
          description="Du dimensionnement solaire à la mise en service des feux tricolores, chaque chantier est étudié avant d'être installé. Choisissez un service pour nous écrire directement sur WhatsApp."
        />

        <div className="mt-10 grid gap-4 sm:gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service, index) => {
            const Icon = icons[index];
            const tone = tones[index];
            return (
              <article
                key={service.title}
                className="group relative flex flex-col rounded-2xl border border-[#E9EDF2] bg-white p-5 md:p-6 shadow-[0_2px_12px_rgba(15,42,66,0.04)] transition-all duration-300 hover:border-[#00B4D8] hover:-translate-y-[5px] hover:shadow-[0_20px_40px_-24px_rgba(0,118,192,0.45)] overflow-hidden"
              >
                <span className="absolute inset-x-0 top-0 h-[3px] bg-gradient-to-r from-[#0076C0] to-[#00B4D8] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <span
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ backgroundColor: tone.bg, color: tone.color }}
                >
                  <Icon size={22} strokeWidth={2} />
                </span>
                <h3 className="mt-4 [font-family:var(--font-montserrat)] text-[17px] font-bold text-[#0E2C42]">
                  {service.title}
                </h3>
                <p className="mt-2 text-[14px] leading-[1.65] text-[#5A6B7C] flex-1">
                  {service.description}
                </p>
                <a
                  href={waLink(service.message)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex items-center gap-2 min-h-[48px] text-sm font-semibold text-[#0076C0] hover:text-[#00B4D8] transition-colors duration-200 cursor-pointer"
                >
                  <span className="w-8 h-8 rounded-lg bg-[#F1F9FD] flex items-center justify-center">
                    <MessageCircle size={15} strokeWidth={2.2} />
                  </span>
                  Devis pour ce service
                  <ArrowRight size={15} className="transition-transform duration-200 group-hover:translate-x-1" />
                </a>
              </article>
            );
          })}
        </div>

        <div
          className="mt-9 flex flex-col sm:flex-row items-center justify-between gap-4 rounded-2xl px-5 py-6 md:px-8"
          style={{ background: "linear-gradient(120deg,#0076C0 0%,#00B4D8 100%)" }}
        >
          <p className="text-sm md:text-[15px] text-white/90 text-center sm:text-left">
            Vous ne savez pas quelle solution choisir ? Décrivez votre besoin,
            nous vous orientons.
          </p>
          <a
            href={WA_DEVIS}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 min-h-[50px] px-6 rounded-[10px] bg-white text-[#0076C0] text-sm font-semibold whitespace-nowrap hover:bg-[#F0FAFD] transition-colors duration-200 cursor-pointer"
          >
            <MessageCircle size={17} strokeWidth={2.2} />
            Écrire sur WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}