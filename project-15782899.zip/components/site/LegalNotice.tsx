"use client";

import { useState } from "react";
import { X, FileText } from "lucide-react";
import { PHONE_PRIMARY_DISPLAY, PHONE_PRIMARY_HREF } from "../../lib/site";

const lines = [
  { label: "Éditeur du site", value: "TECHNO FAB SARL-U" },
  { label: "Siège social", value: "Lomé, Bè Kpota Colas — Togo" },
  { label: "NIF", value: "1001751745" },
  { label: "Directeur de la publication", value: "M. MISSIAMENOU YAWOVI" },
  { label: "Hébergement", value: "Readdy (plateforme d'hébergement du site)" },
];

export default function LegalNotice() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="text-[12px] text-white/55 underline underline-offset-4 decoration-white/25 hover:text-white transition-colors duration-200 cursor-pointer"
      >
        Mentions légales
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center bg-[#062E4A]/60 backdrop-blur-sm p-0 sm:p-5"
          role="dialog"
          aria-modal="true"
          aria-label="Mentions légales"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full sm:max-w-lg max-h-[88vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl bg-white p-6 md:p-8 shadow-[0_30px_70px_-30px_rgba(6,46,74,0.6)]"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-2.5">
                <span className="w-9 h-9 rounded-lg bg-[#EAF4FB] text-[#0076C0] flex items-center justify-center">
                  <FileText size={17} />
                </span>
                <h2 className="[font-family:var(--font-montserrat)] text-[18px] font-extrabold text-[#0076C0]">
                  Mentions légales
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Fermer les mentions légales"
                className="w-10 h-10 shrink-0 rounded-lg border border-[#E6EDF3] text-[#5A6B7C] flex items-center justify-center hover:bg-[#F4F7FA] transition-colors duration-200 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <p className="mt-5 text-[14px] leading-[1.7] text-[#4C5F70]">
              Site édité par TECHNO FAB SARL-U.
            </p>

            <dl className="mt-4 divide-y divide-[#EFF3F7] border-y border-[#EFF3F7]">
              {lines.map((line) => (
                <div key={line.label} className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-4 py-2.5">
                  <dt className="text-[12px] uppercase tracking-[0.08em] text-[#8A97A6] sm:w-52 shrink-0">
                    {line.label}
                  </dt>
                  <dd className="text-[14px] font-medium text-[#1E3A4F]">{line.value}</dd>
                </div>
              ))}
            </dl>

            <p className="mt-4 text-[14px] leading-[1.7] text-[#4C5F70]">
              Pour toute question :{" "}
              <a
                href={PHONE_PRIMARY_HREF}
                className="font-semibold text-[#0076C0] hover:text-[#00B4D8] transition-colors duration-200 cursor-pointer"
              >
                {PHONE_PRIMARY_DISPLAY}
              </a>
            </p>

            <button
              type="button"
              onClick={() => setOpen(false)}
              className="mt-6 w-full min-h-[48px] rounded-[10px] bg-gradient-to-r from-[#0076C0] to-[#00B4D8] text-white text-sm font-semibold whitespace-nowrap cursor-pointer"
            >
              Fermer
            </button>
          </div>
        </div>
      )}
    </>
  );
}