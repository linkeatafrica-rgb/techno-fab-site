import { MessageCircle, ClipboardList, PackageCheck, Sparkles, ShieldCheck } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { reasons, waLink } from "../../lib/site";

const icons = [ClipboardList, PackageCheck, Sparkles, ShieldCheck];

export default function WhyUs() {
  return (
    <section id="pourquoi" className="scroll-mt-24 bg-white px-5 md:px-10 py-14 md:py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="POURQUOI NOUS"
          title="Quatre règles que nous tenons sur chaque chantier"
          description="Nous ne promettons pas le moins cher. Nous promettons une installation étudiée, propre et suivie."
        />

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {reasons.map((reason, index) => {
            const Icon = icons[index];
            return (
              <div
                key={reason.number}
                className="group rounded-2xl border border-[#E9EDF2] bg-[#F8F9FA] p-5 md:p-6 shadow-[0_2px_12px_rgba(15,42,66,0.04)] transition-all duration-300 hover:border-[#00B4D8] hover:bg-white hover:-translate-y-[3px]"
              >
                <div className="flex items-center justify-between">
                  <span className="w-10 h-10 rounded-xl bg-[#EAF4FB] text-[#0076C0] flex items-center justify-center group-hover:bg-[#E8F8FC] group-hover:text-[#00B4D8] transition-colors duration-200">
                    <Icon size={19} strokeWidth={2} />
                  </span>
                  <span className="[font-family:var(--font-montserrat)] text-[22px] font-extrabold text-[#E4EBF2]">
                    {reason.number}
                  </span>
                </div>
                <h3 className="mt-4 [font-family:var(--font-montserrat)] text-[16px] font-bold text-[#0E2C42]">
                  {reason.title}
                </h3>
                <p className="mt-2 text-[13.5px] leading-[1.65] text-[#5A6B7C]">
                  {reason.description}
                </p>
              </div>
            );
          })}
        </div>

        <div className="mt-9 flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6">
          <a
            href={waLink("Bonjour TECHNO FAB, je souhaite une étude pour mon projet.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 min-h-[52px] px-6 rounded-[10px] bg-gradient-to-r from-[#0076C0] to-[#00B4D8] text-white text-[14px] font-semibold whitespace-nowrap shadow-[0_10px_24px_-12px_rgba(0,118,192,0.9)] hover:shadow-[0_14px_28px_-12px_rgba(0,118,192,1)] transition-all duration-200 cursor-pointer self-start"
          >
            <MessageCircle size={17} strokeWidth={2.2} />
            Demander une étude
          </a>
          <p className="text-[13px] text-[#6B7C8F]">
            Réponse par message, sans engagement. Devis écrit sur demande.
          </p>
        </div>
      </div>
    </section>
  );
}