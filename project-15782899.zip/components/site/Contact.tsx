import type { ReactNode } from "react";
import { MapPin, Phone, Clock, FileText, MessageCircle } from "lucide-react";
import SectionHeading from "./SectionHeading";
import {
  PHONE_PRIMARY_DISPLAY,
  PHONE_PRIMARY_HREF,
  PHONE_SECONDARY_DISPLAY,
  PHONE_SECONDARY_HREF,
  WA_DEVIS,
} from "../../lib/site";

export default function Contact() {
  return (
    <section id="contact" className="scroll-mt-24 bg-[#F8F9FA] px-5 md:px-10 py-14 md:py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="CONTACT"
          title="Parlons de votre installation dès aujourd'hui"
          description="Un message suffit. Décrivez votre besoin ou votre problème, nous répondons avec une solution et un prix."
        />

        <div className="mt-10 grid gap-4 md:gap-5 lg:grid-cols-[1fr_0.85fr]">
          <div className="grid gap-4 sm:grid-cols-2">
            <InfoCard icon={<MapPin size={18} />} label="Adresse">
              Lomé, Bè Kpota Colas
              <br />
              Togo
            </InfoCard>
            <InfoCard icon={<Clock size={18} />} label="Horaires">
              Lundi – Samedi
              <br />
              8h – 18h
            </InfoCard>
            <InfoCard icon={<Phone size={18} />} label="Téléphones">
              <a href={PHONE_PRIMARY_HREF} className="block hover:text-[#0076C0] transition-colors duration-200 cursor-pointer">
                {PHONE_PRIMARY_DISPLAY}
              </a>
              <a href={PHONE_SECONDARY_HREF} className="block hover:text-[#0076C0] transition-colors duration-200 cursor-pointer">
                {PHONE_SECONDARY_DISPLAY}
              </a>
            </InfoCard>
            <InfoCard icon={<FileText size={18} />} label="NIF">
              1001751745
            </InfoCard>
          </div>

          <div
            className="relative overflow-hidden rounded-2xl p-6 md:p-7 text-white shadow-[0_28px_60px_-32px_rgba(0,118,192,0.75)]"
            style={{ background: "linear-gradient(140deg,#0076C0 0%,#00B4D8 100%)" }}
          >
            <div
              aria-hidden
              className="absolute -top-16 -right-16 w-56 h-56 rounded-full bg-white/15 blur-[40px]"
            />
            <div className="relative">
              <p className="text-[11px] font-semibold tracking-[0.2em] text-[#D8F4FF]">
                LE PLUS RAPIDE
              </p>
              <h3 className="mt-3 [font-family:var(--font-montserrat)] text-[22px] md:text-[24px] font-extrabold leading-snug">
                Envoyez votre demande sur WhatsApp
              </h3>
              <p className="mt-3 text-[14px] leading-[1.7] text-white/80">
                Photos, note vocale ou simple message : nous regardons votre
                situation et revenons avec une proposition claire.
              </p>
              <div className="mt-6 space-y-3">
                <a
                  href={WA_DEVIS}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex w-full items-center justify-center gap-2 min-h-[54px] rounded-[10px] bg-gradient-to-r from-[#25D366] to-[#1FB35A] text-white text-[15px] font-semibold whitespace-nowrap shadow-[0_10px_24px_-12px_rgba(0,0,0,0.5)] hover:opacity-95 transition-opacity duration-200 cursor-pointer"
                >
                  <MessageCircle size={19} strokeWidth={2.3} />
                  Écrire sur WhatsApp
                </a>
                <a
                  href={PHONE_PRIMARY_HREF}
                  className="inline-flex w-full items-center justify-center gap-2 min-h-[54px] rounded-[10px] bg-white/15 border border-white/40 backdrop-blur-sm text-white text-[15px] font-semibold whitespace-nowrap hover:bg-white/25 transition-colors duration-200 cursor-pointer"
                >
                  <Phone size={17} />
                  Appeler le {PHONE_PRIMARY_DISPLAY}
                </a>
              </div>
              <p className="mt-4 text-[12px] text-white/65">
                WhatsApp principal : +228 90 88 34 85
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function InfoCard({
  icon,
  label,
  children,
}: {
  icon: ReactNode;
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-[#E9EDF2] bg-white p-5 shadow-[0_2px_12px_rgba(15,42,66,0.04)] transition-colors duration-200 hover:border-[#00B4D8]">
      <span className="w-10 h-10 rounded-lg bg-[#EAF4FB] text-[#0076C0] flex items-center justify-center">
        {icon}
      </span>
      <p className="mt-3.5 text-[11px] uppercase tracking-wider text-[#93A2B1]">
        {label}
      </p>
      <div className="mt-1 text-[14px] font-medium text-[#0E2C42] leading-relaxed">
        {children}
      </div>
    </div>
  );
}