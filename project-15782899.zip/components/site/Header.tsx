"use client";

import { useState } from "react";
import { Menu, X, ChevronRight, MessageCircle } from "lucide-react";
import { WA_DEVIS, LOGO_URL } from "../../lib/site";

const NAV = [
  { href: "#services", label: "Services" },
  { href: "#realisations", label: "Réalisations" },
  { href: "#pourquoi", label: "Pourquoi nous" },
  { href: "#apropos", label: "À propos" },
  { href: "#contact", label: "Contact" },
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-[#EDF1F5] shadow-[0_2px_14px_rgba(0,118,192,0.06)]">
      <div className="flex items-center justify-between gap-4 px-5 md:px-10 h-[68px] md:h-20">
        <a href="#top" className="flex items-center gap-2.5 md:gap-3 shrink-0 cursor-pointer">
          <img
            src={LOGO_URL}
            alt="Logo TECHNO FAB"
            className="h-10 md:h-[46px] w-auto object-contain"
          />
          <span className="leading-tight">
            <span className="block [font-family:var(--font-montserrat)] font-extrabold tracking-tight text-[14px] md:text-[17px] text-[#0076C0]">
              TECHNO FAB
            </span>
            <span className="block text-[8.5px] md:text-[10px] tracking-[0.16em] text-[#6B7C8F] font-medium">
              SARL-U • LOMÉ
            </span>
          </span>
        </a>

        <nav className="hidden lg:flex items-center gap-5 xl:gap-8">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="group relative text-[13px] xl:text-sm font-medium text-[#3A4B5C] hover:text-[#0076C0] transition-colors duration-200 cursor-pointer whitespace-nowrap"
            >
              {item.label}
              <span className="absolute -bottom-1.5 left-0 h-[2px] w-0 bg-[#00B4D8] transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={WA_DEVIS}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 h-11 px-5 rounded-[10px] bg-gradient-to-r from-[#25D366] to-[#1FB35A] text-white text-sm font-semibold whitespace-nowrap shadow-[0_6px_16px_-6px_rgba(37,211,102,0.7)] hover:shadow-[0_8px_22px_-6px_rgba(37,211,102,0.85)] transition-all duration-200 cursor-pointer"
          >
            <MessageCircle size={17} strokeWidth={2.3} />
            Devis WhatsApp
          </a>
          <a
            href={WA_DEVIS}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Demander un devis sur WhatsApp"
            className="sm:hidden w-12 h-12 rounded-[10px] bg-gradient-to-r from-[#25D366] to-[#1FB35A] text-white flex items-center justify-center cursor-pointer"
          >
            <MessageCircle size={19} strokeWidth={2.3} />
          </a>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
            className="lg:hidden w-12 h-12 rounded-[10px] border border-[#DDE6EE] text-[#0076C0] flex items-center justify-center cursor-pointer"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {open && (
        <nav
        id="mobile-nav"
        className="lg:hidden border-t border-[#EDF1F5] bg-white px-5 py-3"
      >
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="flex items-center justify-between min-h-[52px] px-1 text-[15px] font-medium text-[#1E3A4F] border-b border-[#F1F4F8] last:border-0 cursor-pointer"
            >
              {item.label}
              <ChevronRight size={18} className="text-[#00B4D8]" />
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}