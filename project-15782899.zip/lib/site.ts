export const LOGO_URL =
  "https://public.readdy.ai/ai/img_res/edited_c523fe79346fa995bc9b866945167b32_8aa3de59.jpg";

export const PHONE_PRIMARY_DISPLAY = "+228 90 88 34 85";
export const PHONE_SECONDARY_DISPLAY = "+228 98 61 98 63";
export const PHONE_PRIMARY_HREF = "tel:+22890883485";
export const PHONE_SECONDARY_HREF = "tel:+22898619863";

export const waLink = (message: string) =>
  `https://wa.me/22890883485?text=${encodeURIComponent(message)}`;

export const WA_DEVIS = waLink(
  "Bonjour TECHNO FAB, je souhaite un devis."
);

export const WA_APPEL = waLink(
  "Bonjour TECHNO FAB, j'aimerais être rappelé pour un projet."
);

export const WA_REALISATIONS = waLink(
  "Bonjour, j'aimerais voir vos réalisations en photos."
);

export type Service = {
  emoji: string;
  title: string;
  description: string;
  message: string;
};

export const services: Service[] = [
  {
    emoji: "☀️",
    title: "Énergie solaire",
    description:
      "Étude et dimensionnement selon votre consommation réelle, puis installation de panneaux, onduleurs et batteries adaptés à votre budget.",
    message:
      "Bonjour TECHNO FAB, je souhaite un devis pour une installation solaire.",
  },
  {
    emoji: "💡",
    title: "Efficacité énergétique",
    description:
      "Audit de votre consommation, passage en éclairage LED et régulation intelligente pour faire baisser la facture d'électricité.",
    message:
      "Bonjour TECHNO FAB, je souhaite un devis pour un audit énergétique et un éclairage LED.",
  },
  {
    emoji: "⚡",
    title: "Électricité courant fort",
    description:
      "Installations de bâtiment et industrielles, tableaux électriques, câblage complet et mise aux normes de vos locaux.",
    message:
      "Bonjour TECHNO FAB, je souhaite un devis pour une installation électrique courant fort.",
  },
  {
    emoji: "🔌",
    title: "Courant faible",
    description:
      "Réseaux structurés, téléphonie, internet et contrôle d'accès : un bâtiment câblé proprement, prêt à évoluer.",
    message:
      "Bonjour TECHNO FAB, je souhaite un devis pour un réseau courant faible (internet, téléphonie, contrôle d'accès).",
  },
  {
    emoji: "📹",
    title: "Caméras de surveillance",
    description:
      "Installation professionnelle, vision 24h/24 et accès à distance depuis votre téléphone, où que vous soyez.",
    message:
      "Bonjour TECHNO FAB, je souhaite un devis pour l'installation de caméras de surveillance.",
  },
  {
    emoji: "🚦",
    title: "Feux tricolores",
    description:
      "Étude, installation et mise en service de systèmes de feux tricolores pour carrefours et voiries.",
    message:
      "Bonjour TECHNO FAB, je souhaite un devis pour un système de feux tricolores.",
  },
];

export const reasons = [
  {
    number: "01",
    title: "Étude sur mesure",
    description:
      "Nous mesurons votre consommation et vos contraintes avant de proposer quoi que ce soit. Pas de devis au hasard.",
  },
  {
    number: "02",
    title: "Matériel de qualité",
    description:
      "Des équipements choisis pour durer sous le climat togolais, dimensionnés pour votre usage réel.",
  },
  {
    number: "03",
    title: "Installation propre",
    description:
      "Câblage soigné, repérage clair, chantier laissé en ordre. Une installation que vous pouvez montrer.",
  },
  {
    number: "04",
    title: "Garantie & SAV",
    description:
      "Nous restons joignables après la mise en service, sur WhatsApp comme au téléphone, à Lomé.",
  },
];

export const specialties = [
  "Énergie solaire",
  "Efficacité énergétique",
  "Électricité courant fort",
  "Courant faible",
  "Caméras de surveillance",
  "Feux tricolores",
];