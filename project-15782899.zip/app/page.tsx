import Header from "../components/site/Header";
import Hero from "../components/site/Hero";
import Services from "../components/site/Services";
import Realisations from "../components/site/Realisations";
import WhyUs from "../components/site/WhyUs";
import About from "../components/site/About";
import Contact from "../components/site/Contact";
import Footer from "../components/site/Footer";
import FloatingWhatsApp from "../components/site/FloatingWhatsApp";
import { MapPin, FileText, ShieldCheck } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />

        <div className="border-b border-[#EDF1F5] bg-white px-5 md:px-10">
          <div className="mx-auto flex max-w-6xl flex-col sm:flex-row sm:items-center justify-between gap-3 py-4 text-[12.5px] text-[#4C5F70]">
            <span className="inline-flex items-center gap-2">
              <MapPin size={15} className="text-[#0076C0]" />
              Siège : Lomé, Bè Kpota Colas
            </span>
            <span className="inline-flex items-center gap-2">
              <FileText size={15} className="text-[#00B4D8]" />
              NIF : 1001751745
            </span>
            <span className="inline-flex items-center gap-2">
              <ShieldCheck size={15} className="text-[#2A9D8F]" />
              Installations garanties, SAV local
            </span>
          </div>
        </div>

        <Services />
        <Realisations />
        <WhyUs />
        <About />
        <Contact />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}