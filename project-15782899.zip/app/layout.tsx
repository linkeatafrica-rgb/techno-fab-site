import type { Metadata } from "next";
import { Montserrat, Poppins } from "next/font/google";
import "./globals.css";
import { LOGO_URL } from "../lib/site";

const montserrat = Montserrat({
  weight: ["700", "800"],
  subsets: ["latin"],
  display: "swap",
  variable: "--font-montserrat",
});

const poppins = Poppins({
  weight: ["400", "500", "600"],
  subsets: ["latin"],
  display: "swap",
  variable: "--font-poppins",
});

export const metadata: Metadata = {
  title: "TECHNO FAB SARL-U — Électricité, solaire et sécurité à Lomé",
  description:
    "PME togolaise basée à Bè Kpota Colas, Lomé : installation solaire, efficacité énergétique, électricité courant fort et faible, caméras de surveillance et feux tricolores. Devis direct sur WhatsApp.",
  keywords: [
    "électricien Lomé",
    "installation solaire Togo",
    "caméras surveillance Lomé",
    "feux tricolores Togo",
    "efficacité énergétique Lomé",
    "courant faible Togo",
  ],
  openGraph: {
    title: "TECHNO FAB SARL-U — Électricité, solaire et sécurité à Lomé",
    description:
      "Étude et installation solaire, électricité, caméras de surveillance et feux tricolores à Lomé. Devis WhatsApp direct.",
    type: "website",
    locale: "fr_FR",
    siteName: "TECHNO FAB SARL-U",
  },
};

const businessSchema = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "TECHNO FAB SARL-U",
  description:
    "Installation solaire, efficacité énergétique, électricité courant fort et faible, caméras de surveillance et feux tricolores à Lomé.",
  telephone: "+22890883485",
  foundingDate: "2021",
  address: {
    "@type": "PostalAddress",
    streetAddress: "Bè Kpota Colas",
    addressLocality: "Lomé",
    addressCountry: "TG",
  },
  openingHours: "Mo-Sa 08:00-18:00",
  taxID: "1001751745",
  areaServed: "Lomé et environs",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning={true} className="scroll-smooth">
      <head>
        <link rel="icon" href={LOGO_URL} />
        <meta name="theme-color" content="#ffffff" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(businessSchema) }}
        />
      </head>
      <body
        className={`${montserrat.variable} ${poppins.variable} antialiased bg-white`}
        style={{ fontFamily: "var(--font-poppins), system-ui, sans-serif" }}
      >
        {children}
      </body>
    </html>
  );
}