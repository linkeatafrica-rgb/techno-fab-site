"use client";

import { useState } from "react";
import { MessageCircle, Images, Maximize2 } from "lucide-react";
import SectionHeading from "./SectionHeading";
import Lightbox from "./Lightbox";
import { WA_REALISATIONS } from "../../lib/site";

type Category = "Tous" | "Solaire" | "Électricité" | "Feux tricolores";

const categories: Category[] = ["Tous", "Solaire", "Électricité", "Feux tricolores"];

const photos: {
  src: string;
  title: string;
  caption: string;
  category: Exclude<Category, "Tous">;
}[] = [
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/90bfcad4-c9e2-4de9-8f91-7263b73da8d7_compressed_IMG-20250610-WA0080.webp",
    title: "Grande toiture solaire",
    caption: "Centrale photovoltaïque en bord de mer",
    category: "Solaire",
  },
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/0f019cf0-cc01-415b-bc91-932c659fa9d0_compressed_IMG-20260606-WA0020.webp",
    title: "Panneaux sur toiture",
    caption: "Champ photovoltaïque posé et raccordé",
    category: "Solaire",
  },
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/a1e45fb8-0a2c-4531-9ad8-1368608f3e0e_compressed_PXL_20260822_091947777.MP.webp",
    title: "Onduleur et batteries",
    caption: "Installation hybride avec armoires de protection",
    category: "Solaire",
  },
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/fdfc2c7d-6a31-482e-9bc9-ca2c1d1744e4_compressed_PXL_20260824_175648615.webp",
    title: "Armoire de conversion",
    caption: "Armoire PCS pour installation de forte puissance",
    category: "Solaire",
  },
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/3c930750-5296-4399-bd6d-44d8b2c23308_compressed_PXL_20260926_120625991.MP.webp",
    title: "Baies de stockage",
    caption: "Batteries lithium empilées et câblées",
    category: "Solaire",
  },
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/21c15a6a-b403-4b57-bbb9-4adf1240fd65_compressed_PXL_20260926_120651899.PORTRAIT.webp",
    title: "Modules de stockage",
    caption: "Raccords et supervision des batteries",
    category: "Solaire",
  },
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/879a5f60-ff2c-4617-9edc-7d6f03e20936_compressed_IMG-20260514-WA0033.webp",
    title: "Parc de batteries",
    caption: "Salle technique et autonomie du site",
    category: "Solaire",
  },
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/98f0a299-2056-4537-bf9a-b2d456b7d29b_compressed_IMG-20261117-WA0000.webp",
    title: "Armoire électrique",
    caption: "Raccordement courant fort et disjoncteurs",
    category: "Électricité",
  },
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/1533c556-b450-4863-b93d-5330da2f8541_compressed_IMG-20261117-WA0001.webp",
    title: "Feux tricolores",
    caption: "Pose des têtes de feux sur mât",
    category: "Feux tricolores",
  },
  {
    src: "https://storage.helloreaddy.io/project_files/c858e1de-025a-49eb-842c-594a9d4bffcf/f0395a7e-84b1-4acb-91ef-0d82a7fd0a0d_compressed_IMG-20261117-WA0002.webp",
    title: "Feux tricolores",
    caption: "Réglage et mise en service sur carrefour",
    category: "Feux tricolores",
  },
];

export default function Realisations() {
  const [active, setActive] = useState<Category>("Tous");
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const visible = active === "Tous" ? photos : photos.filter((p) => p.category === active);

  return (
    <section id="realisations" className="scroll-mt-24 bg-[#F8F9FA] px-5 md:px-10 py-14 md:py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="NOS RÉALISATIONS"
          title="Nos réalisations sur le terrain"
          description="Dix chantiers réels — solaire, électricité et feux tricolores — réalisés par nos équipes."
        />

        <div role="tablist" className="mt-8 inline-flex flex-wrap gap-1 rounded-full border border-[#DCEAF3] bg-white p-1">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              role="tab"
              aria-selected={active === cat}
              onClick={() => setActive(cat)}
              className={`min-h-[40px] rounded-full px-4 md:px-5 text-[13px] md:text-sm font-semibold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                active === cat
                  ? "bg-[#062E4A] text-white shadow-[0_6px_16px_-8px_rgba(6,46,74,0.7)]"
                  : "text-[#4C5F70] hover:bg-[#EAF7F5] hover:text-[#0F6E8C]"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="mt-6 grid gap-4 sm:gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((photo, index) => (
            <figure
              key={photo.src}
              onClick={() => setOpenIndex(index)}
              className="group relative cursor-pointer overflow-hidden rounded-[12px] border border-[#E6EDF3] bg-white shadow-[0_2px_12px_rgba(15,42,66,0.05)] transition-all duration-300 hover:border-[#00B4D8] hover:shadow-[0_20px_40px_-24px_rgba(0,118,192,0.45)]"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={photo.src}
                  alt={`${photo.title} — chantier TECHNO FAB à Lomé`}
                  loading="lazy"
                  className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-[1.06]"
                />
              </div>
              <span className="absolute left-3 top-3 rounded-full bg-white/92 px-3 py-1 text-[11px] font-semibold tracking-wide text-[#0F6E8C] backdrop-blur">
                {photo.category}
              </span>
              <span className="absolute right-3 top-3 flex w-9 h-9 items-center justify-center rounded-full bg-[#062E4A]/70 text-white opacity-0 backdrop-blur transition-opacity duration-200 group-hover:opacity-100">
                <Maximize2 size={15} />
              </span>
              <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#062E4A]/88 via-[#062E4A]/55 to-transparent px-5 pb-4 pt-12">
                <p className="[font-family:var(--font-montserrat)] text-[15px] md:text-[16px] font-bold text-white">
                  {photo.title}
                </p>
                <p className="mt-1 text-[12.5px] text-white/80">{photo.caption}</p>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 rounded-2xl border border-[#DCEAF3] bg-white px-5 py-6 md:px-8">
          <p className="inline-flex items-center gap-2.5 text-sm md:text-[15px] text-[#4C5F70] text-center sm:text-left">
            <span className="hidden sm:flex w-9 h-9 rounded-lg bg-[#EAF7F5] text-[#2A9D8F] items-center justify-center">
              <Images size={17} />
            </span>
            Envie de voir d'autres chantiers ? Demandez-nous les photos.
          </p>
          <a
            href={WA_REALISATIONS}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 min-h-[50px] px-6 rounded-[10px] bg-gradient-to-r from-[#25D366] to-[#1FB35A] text-white text-sm font-semibold whitespace-nowrap shadow-[0_8px_20px_-10px_rgba(37,211,102,0.8)] hover:shadow-[0_10px_26px_-10px_rgba(37,211,102,0.9)] transition-all duration-200 cursor-pointer"
          >
            <MessageCircle size={17} strokeWidth={2.3} />
            Voir plus de photos sur WhatsApp
          </a>
        </div>
      </div>

      {openIndex !== null && (
        <Lightbox
          photos={visible}
          index={openIndex}
          onClose={() => setOpenIndex(null)}
          onPrev={() => setOpenIndex((openIndex - 1 + visible.length) % visible.length)}
          onNext={() => setOpenIndex((openIndex + 1) % visible.length)}
        />
      )}
    </section>
  );
}