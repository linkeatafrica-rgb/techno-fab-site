"use client";

import { useEffect } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

type LightboxPhoto = {
  src: string;
  title: string;
  caption: string;
  category: string;
};

type Props = {
  photos: LightboxPhoto[];
  index: number;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
};

export default function Lightbox({ photos, index, onClose, onPrev, onNext }: Props) {
  const photo = photos[index];

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "ArrowLeft") onPrev();
      if (event.key === "ArrowRight") onNext();
    };
    document.addEventListener("keydown", onKey);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [onClose, onPrev, onNext]);

  if (!photo) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={photo.title}
      onClick={onClose}
      className="fixed inset-0 z-[120] flex items-center justify-center bg-[#041B2C]/92 px-4 py-6 backdrop-blur-sm"
    >
      <button
        type="button"
        onClick={onClose}
        aria-label="Fermer"
        className="absolute right-4 top-4 flex h-11 w-11 items-center justify-center rounded-full bg-white/12 text-white transition-colors duration-200 hover:bg-white/25 cursor-pointer"
      >
        <X size={21} />
      </button>

      {photos.length > 1 && (
        <>
          <button
            type="button"
            aria-label="Photo précédente"
            onClick={(event) => {
              event.stopPropagation();
              onPrev();
            }}
            className="absolute left-2 md:left-6 flex h-12 w-12 items-center justify-center rounded-full bg-white/12 text-white transition-colors duration-200 hover:bg-white/25 cursor-pointer"
          >
            <ChevronLeft size={24} />
          </button>
          <button
            type="button"
            aria-label="Photo suivante"
            onClick={(event) => {
              event.stopPropagation();
              onNext();
            }}
            className="absolute right-2 md:right-6 flex h-12 w-12 items-center justify-center rounded-full bg-white/12 text-white transition-colors duration-200 hover:bg-white/25 cursor-pointer"
          >
            <ChevronRight size={24} />
          </button>
        </>
      )}

      <figure
        onClick={(event) => event.stopPropagation()}
        className="flex max-h-full w-full max-w-4xl flex-col items-center"
      >
        <img
          src={photo.src}
          alt={`${photo.title} — chantier TECHNO FAB à Lomé`}
          className="max-h-[74vh] w-auto max-w-full rounded-xl object-contain shadow-[0_30px_80px_-30px_rgba(0,0,0,0.8)]"
        />
        <figcaption className="mt-4 text-center">
          <p className="[font-family:var(--font-montserrat)] text-[16px] md:text-[18px] font-bold text-white">
            {photo.title}
          </p>
          <p className="mt-1 text-[13px] md:text-sm text-white/70">{photo.caption}</p>
          <p className="mt-2 text-[11.5px] uppercase tracking-[0.14em] text-white/40">
            {photo.category} · {index + 1} / {photos.length}
          </p>
        </figcaption>
      </figure>
    </div>
  );
}